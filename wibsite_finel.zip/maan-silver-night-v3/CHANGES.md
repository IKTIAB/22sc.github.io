# Maan — Silver Night · v3.1

## ما الجديد في هذه النسخة (What's New)
1. **أفتار جديد** — `public/covers/avatar.gif` (الصورة الزرقاء المتحركة).
2. **مشغّل موسيقى معاد تصميمه**:
   - أسفل يسار الشاشة دائماً.
   - مظهر شفاف/فضّي (glass / translucent) بدل اللون الذهبي.
   - يظهر اسم المقطوعة المختصر **Sima / سيما** واسم المغنّي **Amir Eid / أمير عيد**.
3. **أغلفة محلية كاملة** لكل الكتب/الأنمي/الأفلام من مجلد Pins.
4. **الروايات الجديدة**: هذا ما حدث معها، بساتين عربستان، أرض زيكولا — إضافةً للروايات السابقة (النداء، خوف، شبكة العنكبوت، جحيم العابرين، هذا ما حدث معي).
5. **بطاقة شعر أبيات المتنبّي** الستّ بجانب الأفتار (ذهبية أنيقة بخط Amiri).

## كيفية التشغيل (How to run)

### Backend
```bash
cd backend
pip install -r requirements.txt
# ضع ملف .env يحوي:
# MONGO_URL=mongodb://localhost:27017
# DB_NAME=maan
# ADMIN_PASSWORD=<your password>
uvicorn server:app --host 0.0.0.0 --port 8001 --reload
```

### Frontend
```bash
cd frontend
yarn install
# ضع ملف .env يحوي:
# REACT_APP_BACKEND_URL=http://localhost:8001
yarn start
```

## الملفات الرئيسية المعدَّلة
- `frontend/src/data.js` — الأغلفة المحلية + الأفتار الجديد + أبيات الشعر + الروايات الجديدة
- `frontend/src/App.js` — دمج بطاقة الشعر + المشغّل + تحميل آمن
- `frontend/src/components/MusicPlayer.jsx` — المشغّل الجديد (Sima / Amir Eid)
- `frontend/src/index.css` — أنماط المشغّل الشفاف + بطاقة الشعر
- `frontend/public/covers/*` — أغلفة محلية + `avatar.gif`
- `frontend/public/audio/sima.mp3` — المقطوعة الموسيقية
