from fastapi import FastAPI, APIRouter, HTTPException, Header, Depends
from dotenv import load_dotenv
from starlette.middleware.cors import CORSMiddleware
from motor.motor_asyncio import AsyncIOMotorClient
import os
import logging
import secrets
from pathlib import Path
from pydantic import BaseModel, Field, ConfigDict
from typing import List, Optional, Dict, Any
import uuid
from datetime import datetime, timezone
import requests
from urllib.parse import quote

ROOT_DIR = Path(__file__).parent
load_dotenv(ROOT_DIR / '.env')

mongo_url = os.environ['MONGO_URL']
client = AsyncIOMotorClient(mongo_url)
db = client[os.environ['DB_NAME']]

ADMIN_PASSWORD = os.environ.get('ADMIN_PASSWORD', 'maannight2026')
# Issued session tokens (in-memory). For admin personal tool this is acceptable.
ADMIN_TOKENS: set = set()

app = FastAPI()
api_router = APIRouter(prefix="/api")

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)


# ---------------- Models ----------------
class GuestEntry(BaseModel):
    model_config = ConfigDict(extra="ignore")
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    name: str
    message: Optional[str] = ""
    hidden: bool = False
    created_at: str = Field(default_factory=lambda: datetime.now(timezone.utc).isoformat())


class GuestCreate(BaseModel):
    name: str
    message: Optional[str] = ""


class AdminLogin(BaseModel):
    password: str


class ContentUpdate(BaseModel):
    data: Dict[str, Any]


class CoverOverride(BaseModel):
    section: str  # books | anime | movies
    item_id: str
    cover_url: str


# ---------------- Default content seed ----------------
DEFAULT_CONTENT: Dict[str, Any] = {
    "identity": {
        "name": "MAAN",
        "arabic": "معن",
        "tagline": "Silver Night",
        "avatar": "https://images.unsplash.com/photo-1534447677768-be436bb09401?w=900&q=80",
        "description": "Living between the stadium, the court and the open desert. A quiet portfolio — a silver-night pocket of the web, home to memories, hobbies, books, anime, movies and a small guestbook of visitors.",
        "description_ar": "أعيش بين الملعب والساحة والصحراء المفتوحة. زاوية هادئة على الويب — جيبٌ من الليل الفضي يضمّ الذكريات والهوايات والكتب والأنمي والأفلام ودفتر زوّار صغير.",
        "stats": [
            {"value": "10+", "label": "Years Playing", "label_ar": "سنوات لعب"},
            {"value": "3 AM", "label": "Favorite Hour", "label_ar": "الساعة المفضّلة"},
            {"value": "Midnight", "label": "Mood", "label_ar": "المزاج"},
        ],
    },
    "verse": {
        "ar": "وأنا أمشي إلى نفسي وحيداً، لا أضلُّ الدربَ نحوي",
        "en": '"I walk to myself alone — I never lose the path to me."',
        "author": "محمود درويش",
    },
    "about": {
        "title": "A night owl with a daylight heart.",
        "title_ar": "بومةُ ليلٍ بقلبِ نهار.",
        "body": "My name is Maan (معن). I find beauty in motion — the roar of a crowd, the squeak of sneakers on hardwood, the thunder of hooves against open ground. Quiet by nature, loud in passion, at home somewhere between midnight and the first whistle.",
        "body_ar": "اسمي معن. أجد الجمال في الحركة — هدير الجمهور، صرير الأحذية على الخشب، دويّ الحوافر على الأرض المفتوحة. هادئ بطبعي، صاخبٌ في شغفي، وطني في مكانٍ ما بين منتصف الليل وصافرة البداية.",
        "cards": [
            {"label": "Identity", "label_ar": "الهويّة", "value": "Maan · معن", "sub": "", "sub_ar": ""},
            {"label": "Mood", "label_ar": "المزاج", "value": "Midnight Silver", "value_ar": "فضّة منتصف الليل", "sub": "Calm, focused, a little mysterious.", "sub_ar": "هادئ، مركّز، غامضٌ بعض الشيء."},
        ],
    },
    "hobbies": [
        {"n": "01", "title": "Football", "title_ar": "كرة القدم", "subtitle": "THE BEAUTIFUL GAME", "subtitle_ar": "اللعبة الجميلة", "desc": "Ninety minutes where the world stops existing. The grass, the lights, the ball — nothing else matters.", "desc_ar": "تسعون دقيقة يتوقف فيها العالم. العشب، الأضواء، الكرة — لا شيء آخر يهمّ.", "years": "10Y", "percent": 95},
        {"n": "02", "title": "Basketball", "title_ar": "كرة السلة", "subtitle": "ABOVE THE RIM", "subtitle_ar": "فوق الطوق", "desc": "Rhythm, rebound, rise. Basketball is jazz played with a ball — improvised and electric.", "desc_ar": "إيقاع، ارتداد، صعود. كرة السلة جاز يُعزف بالكرة — ارتجالي وكهربائي.", "years": "6Y", "percent": 70},
        {"n": "03", "title": "Horse Riding", "title_ar": "ركوب الخيل", "subtitle": "BOND WITH THE WIND", "subtitle_ar": "عهدٌ مع الريح", "desc": "Silence that only exists between a rider and their horse. No engines, no noise — just trust and gallop.", "desc_ar": "صمتٌ لا يوجد إلا بين الفارس وحصانه. لا محركات ولا ضجيج — فقط ثقة وعَدْو.", "years": "8Y", "percent": 80},
    ],
    "journey": [
        {"year": "2016", "title": "FIRST SADDLE", "title_ar": "أول سرج", "desc": "First gallop on open desert ground.", "desc_ar": "أوّل جرية على أرضِ صحراءٍ مفتوحة."},
        {"year": "2019", "title": "COURT REGULAR", "title_ar": "من أهل الملعب", "desc": "Weekly basketball runs with the crew.", "desc_ar": "جولات كرة السلة الأسبوعية مع الشلّة."},
        {"year": "2021", "title": "NIGHT MATCHES", "title_ar": "مباريات الليل", "desc": "Started the late-night football ritual under stadium lights.", "desc_ar": "بدأتُ طقسَ كرة القدم الليلي تحت أضواء الملعب."},
        {"year": "2024", "title": "THIS SPACE", "title_ar": "هذه المساحة", "desc": "Launched this portfolio — a quiet corner of the internet.", "desc_ar": "أطلقتُ هذه الواجهة — ركنٌ هادئ من الإنترنت."},
    ],
    "books": [
        {"id": "call", "tag": "THE CALL SERIES", "tag_ar": "سلسلة النداء", "title": "النداء", "english": "The Call", "author": "Osama Al-Muslim", "author_ar": "أسامة المسلم", "quote": "Hauntingly beautiful. Pulled me in from page one.", "quote_ar": "جميلٌ بشكلٍ يطاردك. شدّني من الصفحة الأولى.", "letter": "ن", "gradA": "#3b1f5e", "gradB": "#6b2d4a", "cover": ""},
        {"id": "khawf", "tag": "KHAWF SERIES", "tag_ar": "سلسلة خوف", "title": "خوف", "english": "Khawf (Fear)", "author": "Osama Al-Muslim", "author_ar": "أسامة المسلم", "quote": "The series that redefined Arabic horror.", "quote_ar": "السلسلة التي أعادت تعريف الرعب العربي.", "letter": "خ", "gradA": "#4a1520", "gradB": "#2a0a15", "cover": ""},
        {"id": "spiderweb", "tag": "THE SPIDERWEB SERIES", "tag_ar": "سلسلة شبكة العنكبوت", "title": "شبكة العنكبوت", "english": "The Spiderweb", "author": "Osama Al-Muslim", "author_ar": "أسامة المسلم", "quote": "Tangled plots, sharp pages — impossible to put down.", "quote_ar": "حبكاتٌ متشابكة، صفحاتٌ حادّة — يستحيل تركه.", "letter": "ش", "gradA": "#1f3a5e", "gradB": "#3a2a4a", "cover": ""},
        {"id": "inferno", "tag": "NOVEL", "tag_ar": "رواية", "title": "جحيم العابرين", "english": "Travelers' Inferno", "author": "Osama Al-Muslim", "author_ar": "أسامة المسلم", "quote": "Dark, vivid, unforgettable.", "quote_ar": "مظلم، حيّ، لا يُنسى.", "letter": "ج", "gradA": "#5e1a1a", "gradB": "#2e0a0a", "cover": ""},
        {"id": "happened", "tag": "TRUE STORIES", "tag_ar": "قصص حقيقية", "title": "هذا ما حدث معي", "english": "This Is What Happened To Me", "author": "Mohammed Al-Salem", "author_ar": "محمد السالم", "quote": "Real stories that feel scarier than fiction.", "quote_ar": "قصصٌ حقيقية تبدو أكثر رعبًا من الخيال.", "letter": "هـ", "gradA": "#1a2e5e", "gradB": "#0a1a3a", "cover": ""},
    ],
    "anime": [
        {"id": "demon-emperor", "title": "Demon Emperor", "title_ar": "الإمبراطور الشيطان", "arabic": "الإمبراطور الشيطان", "meta": "MANHUA · ONGOING", "meta_ar": "مانهوا · مستمرة", "quote": "The one I rank above all. Pure ambition turned into ink.", "quote_ar": "الأفضل عندي بلا منازع. طموحٌ خالصٌ تحوّل إلى حبر.", "featured": True, "cover": ""},
        {"id": "vinland", "title": "Vinland Saga", "title_ar": "ملحمة فينلاند", "meta": "ANIME · 2019 — ONGOING", "meta_ar": "أنمي · 2019 — مستمر", "cover": ""},
        {"id": "deathnote", "title": "Death Note", "title_ar": "مذكرة الموت", "meta": "ANIME · 2006", "meta_ar": "أنمي · 2006", "cover": ""},
        {"id": "naruto", "title": "Naruto", "title_ar": "ناروتو", "meta": "ANIME · 2002", "meta_ar": "أنمي · 2002", "cover": ""},
        {"id": "moriarty", "title": "Moriarty the Patriot", "title_ar": "موريارتي الوطني", "meta": "ANIME · 2020", "meta_ar": "أنمي · 2020", "cover": ""},
        {"id": "blackclover", "title": "Black Clover", "title_ar": "بلاك كلوفر", "meta": "ANIME · 2017", "meta_ar": "أنمي · 2017", "cover": ""},
    ],
    "movies": [
        {"id": "hp", "tag": "THE WIZARDING SAGA", "tag_ar": "ملحمة السحرة", "title": "Harry Potter", "arabic": "هاري بوتر", "extra": "+4", "quote": "The whole series, cover to cover. A childhood constant.", "quote_ar": "السلسلة كاملة، من الغلاف للغلاف. ثابتٌ من الطفولة.", "cover": ""},
        {"id": "mi", "tag": "WITH TOM CRUISE", "tag_ar": "مع توم كروز", "title": "Mission: Impossible", "arabic": "المهمة المستحيلة", "extra": "+3", "quote": "Adrenaline at 30,000 feet. Cruise never breaks.", "quote_ar": "أدرينالين على ارتفاع 30 ألف قدم. كروز لا ينكسر.", "cover": ""},
        {"id": "bb", "tag": "WITH WILL SMITH", "tag_ar": "مع ويل سميث", "title": "Bad Boys", "arabic": "الأولاد الأشقياء", "quote": "Buddy cops, wild chases, and Miami nights.", "quote_ar": "رفاق شرطة، مطاردات جامحة، وليالي ميامي.", "cover": ""},
    ],
    "contacts": [
        {"label": "EMAIL", "value": "f702222@outlook.com", "copy": True},
        {"label": "SNAPCHAT", "value": "mald265724"},
        {"label": "YOUTUBE", "value": "@o2.f7"},
        {"label": "DISCORD", "value": "561344344699830272"},
        {"label": "INSTAGRAM", "value": "@o2ssc"},
        {"label": "TIKTOK", "value": "@______111______111111"},
    ],
}


async def ensure_content_seeded():
    existing = await db.site_content.find_one({"_id": "site"})
    if not existing:
        await db.site_content.insert_one({"_id": "site", **DEFAULT_CONTENT})
        logger.info("Seeded default site content")


# ---------------- Admin auth ----------------
def require_admin(authorization: Optional[str] = Header(None)):
    if not authorization or not authorization.startswith("Bearer "):
        raise HTTPException(status_code=401, detail="Missing token")
    token = authorization.replace("Bearer ", "").strip()
    if token not in ADMIN_TOKENS:
        raise HTTPException(status_code=401, detail="Invalid token")
    return token


@api_router.post("/admin/login")
async def admin_login(body: AdminLogin):
    if body.password != ADMIN_PASSWORD:
        raise HTTPException(status_code=401, detail="Wrong password")
    token = secrets.token_urlsafe(32)
    ADMIN_TOKENS.add(token)
    return {"token": token}


@api_router.post("/admin/verify")
async def admin_verify(token: str = Depends(require_admin)):
    return {"valid": True}


@api_router.post("/admin/logout")
async def admin_logout(token: str = Depends(require_admin)):
    ADMIN_TOKENS.discard(token)
    return {"ok": True}


# ---------------- Content ----------------
@api_router.get("/content")
async def get_content():
    await ensure_content_seeded()
    doc = await db.site_content.find_one({"_id": "site"}, {"_id": 0})
    return doc or {}


@api_router.put("/content")
async def update_content(body: ContentUpdate, token: str = Depends(require_admin)):
    data = body.data or {}
    # Remove _id to prevent overwriting
    data.pop("_id", None)
    await db.site_content.update_one({"_id": "site"}, {"$set": data}, upsert=True)
    doc = await db.site_content.find_one({"_id": "site"}, {"_id": 0})
    return doc or {}


@api_router.post("/content/reset")
async def reset_content(token: str = Depends(require_admin)):
    await db.site_content.replace_one({"_id": "site"}, {"_id": "site", **DEFAULT_CONTENT}, upsert=True)
    doc = await db.site_content.find_one({"_id": "site"}, {"_id": 0})
    return doc or {}


# ---------------- Cover fetchers ----------------
def fetch_google_books(query: str, author: Optional[str] = None) -> Optional[str]:
    try:
        q = query
        if author:
            q = f"{query} inauthor:{author}"
        url = f"https://www.googleapis.com/books/v1/volumes?q={quote(q)}&maxResults=3"
        r = requests.get(url, timeout=6)
        if r.status_code != 200:
            return None
        data = r.json()
        for item in data.get("items", []):
            info = item.get("volumeInfo", {})
            links = info.get("imageLinks", {})
            cover = links.get("extraLarge") or links.get("large") or links.get("medium") or links.get("thumbnail")
            if cover:
                return cover.replace("http://", "https://").replace("&edge=curl", "").replace("zoom=1", "zoom=3")
        return None
    except Exception as e:
        logger.warning(f"Google Books error: {e}")
        return None


def fetch_openlibrary(query: str, author: Optional[str] = None) -> Optional[str]:
    try:
        q = f"{query} {author or ''}".strip()
        url = f"https://openlibrary.org/search.json?q={quote(q)}&limit=3"
        r = requests.get(url, timeout=6)
        if r.status_code != 200:
            return None
        data = r.json()
        for doc in data.get("docs", []):
            cover_i = doc.get("cover_i")
            if cover_i:
                return f"https://covers.openlibrary.org/b/id/{cover_i}-L.jpg"
        return None
    except Exception:
        return None


def fetch_jikan(query: str, kind: str = "anime") -> Optional[str]:
    try:
        endpoint = "manga" if kind in ("manhwa", "manhua", "manga") else "anime"
        url = f"https://api.jikan.moe/v4/{endpoint}?q={quote(query)}&limit=5"
        r = requests.get(url, timeout=8)
        if r.status_code != 200:
            return None
        data = r.json()
        for item in data.get("data", []):
            imgs = item.get("images", {}) or {}
            jpg = imgs.get("jpg", {}) or {}
            webp = imgs.get("webp", {}) or {}
            cover = jpg.get("large_image_url") or jpg.get("image_url") or webp.get("large_image_url")
            if cover:
                return cover
        return None
    except Exception:
        return None


def fetch_itunes_movie(query: str) -> Optional[str]:
    try:
        url = f"https://itunes.apple.com/search?term={quote(query)}&media=movie&limit=5"
        r = requests.get(url, timeout=6)
        if r.status_code != 200:
            return None
        data = r.json()
        for item in data.get("results", []):
            art = item.get("artworkUrl100")
            if art:
                return art.replace("100x100bb", "600x600bb")
        return None
    except Exception:
        return None


class CoverRequest(BaseModel):
    type: str
    query: str
    author: Optional[str] = None


@api_router.post("/covers/fetch")
async def fetch_cover(req: CoverRequest):
    cover = None
    if req.type == "book":
        cover = fetch_google_books(req.query, req.author) or fetch_openlibrary(req.query, req.author)
    elif req.type in ("anime", "manhwa", "manhua", "manga"):
        cover = fetch_jikan(req.query, req.type)
    elif req.type == "movie":
        cover = fetch_itunes_movie(req.query)
    return {"cover": cover, "source": "api" if cover else "none"}


# ---------------- Guestbook ----------------
@api_router.post("/guestbook", response_model=GuestEntry)
async def create_guest(entry: GuestCreate):
    obj = GuestEntry(**entry.model_dump())
    await db.guestbook.insert_one(obj.model_dump())
    return obj


@api_router.get("/guestbook", response_model=List[GuestEntry])
async def list_guests():
    entries = await db.guestbook.find({"hidden": {"$ne": True}}, {"_id": 0}).sort("created_at", -1).to_list(100)
    return entries


@api_router.get("/admin/guestbook")
async def list_guests_admin(token: str = Depends(require_admin)):
    entries = await db.guestbook.find({}, {"_id": 0}).sort("created_at", -1).to_list(500)
    return entries


@api_router.delete("/admin/guestbook/{entry_id}")
async def delete_guest(entry_id: str, token: str = Depends(require_admin)):
    res = await db.guestbook.delete_one({"id": entry_id})
    return {"deleted": res.deleted_count}


@api_router.patch("/admin/guestbook/{entry_id}")
async def toggle_guest(entry_id: str, body: Dict[str, Any], token: str = Depends(require_admin)):
    await db.guestbook.update_one({"id": entry_id}, {"$set": {"hidden": bool(body.get("hidden", False))}})
    return {"ok": True}


@api_router.get("/")
async def root():
    return {"message": "Maan · معن API"}


@app.on_event("startup")
async def on_startup():
    await ensure_content_seeded()


app.include_router(api_router)

app.add_middleware(
    CORSMiddleware,
    allow_credentials=True,
    allow_origins=os.environ.get('CORS_ORIGINS', '*').split(','),
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.on_event("shutdown")
async def shutdown_db_client():
    client.close()
