"""Backend API tests for Maan Portfolio Admin."""
import os
import pytest
import requests

BASE = os.environ.get("REACT_APP_BACKEND_URL", "https://admin-control-panel-51.preview.emergentagent.com").rstrip("/")
API = f"{BASE}/api"
ADMIN_PWD = "maannight2026"


@pytest.fixture(scope="session")
def admin_token():
    r = requests.post(f"{API}/admin/login", json={"password": ADMIN_PWD}, timeout=15)
    assert r.status_code == 200, r.text
    return r.json()["token"]


@pytest.fixture(scope="session")
def auth_headers(admin_token):
    return {"Authorization": f"Bearer {admin_token}"}


# ---------------- Admin auth ----------------
def test_admin_login_wrong_password():
    r = requests.post(f"{API}/admin/login", json={"password": "wrong"}, timeout=15)
    assert r.status_code == 401


def test_admin_login_correct(admin_token):
    assert isinstance(admin_token, str) and len(admin_token) > 10


def test_admin_verify(auth_headers):
    r = requests.post(f"{API}/admin/verify", headers=auth_headers, timeout=15)
    assert r.status_code == 200
    assert r.json()["valid"] is True


def test_admin_verify_no_token():
    r = requests.post(f"{API}/admin/verify", timeout=15)
    assert r.status_code == 401


# ---------------- Content ----------------
def test_get_content_has_sections():
    r = requests.get(f"{API}/content", timeout=15)
    assert r.status_code == 200
    data = r.json()
    for key in ["identity", "verse", "about", "hobbies", "journey", "books", "anime", "movies", "contacts"]:
        assert key in data, f"missing {key}"


def test_put_content_requires_auth():
    r = requests.put(f"{API}/content", json={"data": {"identity": {"name": "X"}}}, timeout=15)
    assert r.status_code == 401


def test_put_content_with_auth(auth_headers):
    # get original
    orig = requests.get(f"{API}/content", timeout=15).json()
    new_identity = dict(orig["identity"])
    new_identity["name"] = "TEST_MAAN"
    r = requests.put(f"{API}/content", json={"data": {"identity": new_identity}}, headers=auth_headers, timeout=15)
    assert r.status_code == 200
    assert r.json()["identity"]["name"] == "TEST_MAAN"
    # verify persistence
    g = requests.get(f"{API}/content", timeout=15).json()
    assert g["identity"]["name"] == "TEST_MAAN"


def test_reset_content(auth_headers):
    r = requests.post(f"{API}/content/reset", headers=auth_headers, timeout=15)
    assert r.status_code == 200
    assert r.json()["identity"]["name"] == "MAAN"


# ---------------- Covers ----------------
def test_cover_book():
    r = requests.post(f"{API}/covers/fetch", json={"type": "book", "query": "Harry Potter", "author": "J.K. Rowling"}, timeout=20)
    assert r.status_code == 200
    assert "cover" in r.json()


def test_cover_anime():
    r = requests.post(f"{API}/covers/fetch", json={"type": "anime", "query": "Naruto"}, timeout=20)
    assert r.status_code == 200


def test_cover_movie():
    r = requests.post(f"{API}/covers/fetch", json={"type": "movie", "query": "Inception"}, timeout=20)
    assert r.status_code == 200


# ---------------- Guestbook ----------------
def test_guestbook_create_and_list():
    r = requests.post(f"{API}/guestbook", json={"name": "TEST_User", "message": "hello"}, timeout=15)
    assert r.status_code == 200
    entry = r.json()
    assert entry["name"] == "TEST_User"
    assert "id" in entry
    # list
    r2 = requests.get(f"{API}/guestbook", timeout=15)
    assert r2.status_code == 200
    ids = [e["id"] for e in r2.json()]
    assert entry["id"] in ids


def test_admin_guestbook_ops(auth_headers):
    # create
    created = requests.post(f"{API}/guestbook", json={"name": "TEST_Admin", "message": "m"}, timeout=15).json()
    eid = created["id"]
    # admin list
    r = requests.get(f"{API}/admin/guestbook", headers=auth_headers, timeout=15)
    assert r.status_code == 200
    # hide
    r = requests.patch(f"{API}/admin/guestbook/{eid}", json={"hidden": True}, headers=auth_headers, timeout=15)
    assert r.status_code == 200
    # public list should exclude
    pub = requests.get(f"{API}/guestbook", timeout=15).json()
    assert eid not in [e["id"] for e in pub]
    # delete
    r = requests.delete(f"{API}/admin/guestbook/{eid}", headers=auth_headers, timeout=15)
    assert r.status_code == 200


def test_admin_logout(auth_headers):
    # Use separate token so other tests not affected
    t = requests.post(f"{API}/admin/login", json={"password": ADMIN_PWD}, timeout=15).json()["token"]
    h = {"Authorization": f"Bearer {t}"}
    r = requests.post(f"{API}/admin/logout", headers=h, timeout=15)
    assert r.status_code == 200
    # verify now fails
    r = requests.post(f"{API}/admin/verify", headers=h, timeout=15)
    assert r.status_code == 401
